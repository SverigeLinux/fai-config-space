#!/bin/bash

cd /root/pxegui
python pxegui.py
